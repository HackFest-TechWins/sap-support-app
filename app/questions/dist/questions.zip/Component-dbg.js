sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("qs.questions.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);